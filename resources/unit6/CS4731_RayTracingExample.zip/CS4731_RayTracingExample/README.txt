To run this program, please download the free and open-source Processing IDE at https://processing.org/download/. 

The program files are simple text files that can be opened with any text editor.